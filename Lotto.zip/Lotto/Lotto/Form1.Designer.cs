﻿namespace Lotto
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.nm_1 = new System.Windows.Forms.NumericUpDown();
            this.nm_2 = new System.Windows.Forms.NumericUpDown();
            this.nm_3 = new System.Windows.Forms.NumericUpDown();
            this.nm_4 = new System.Windows.Forms.NumericUpDown();
            this.nm_5 = new System.Windows.Forms.NumericUpDown();
            this.nm_6 = new System.Windows.Forms.NumericUpDown();
            this.nm_powerball = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btn_Go = new System.Windows.Forms.Button();
            this.btn_Cheat = new System.Windows.Forms.Button();
            this.timeToCheat = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nm_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_powerball)).BeginInit();
            this.SuspendLayout();
            // 
            // nm_1
            // 
            this.nm_1.Location = new System.Drawing.Point(12, 39);
            this.nm_1.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_1.Name = "nm_1";
            this.nm_1.Size = new System.Drawing.Size(44, 20);
            this.nm_1.TabIndex = 0;
            this.nm_1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_2
            // 
            this.nm_2.Location = new System.Drawing.Point(62, 39);
            this.nm_2.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_2.Name = "nm_2";
            this.nm_2.Size = new System.Drawing.Size(44, 20);
            this.nm_2.TabIndex = 1;
            this.nm_2.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_3
            // 
            this.nm_3.Location = new System.Drawing.Point(112, 39);
            this.nm_3.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_3.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_3.Name = "nm_3";
            this.nm_3.Size = new System.Drawing.Size(44, 20);
            this.nm_3.TabIndex = 1;
            this.nm_3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_4
            // 
            this.nm_4.Location = new System.Drawing.Point(162, 39);
            this.nm_4.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_4.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_4.Name = "nm_4";
            this.nm_4.Size = new System.Drawing.Size(44, 20);
            this.nm_4.TabIndex = 1;
            this.nm_4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_5
            // 
            this.nm_5.Location = new System.Drawing.Point(212, 39);
            this.nm_5.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_5.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_5.Name = "nm_5";
            this.nm_5.Size = new System.Drawing.Size(44, 20);
            this.nm_5.TabIndex = 1;
            this.nm_5.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_6
            // 
            this.nm_6.Location = new System.Drawing.Point(262, 39);
            this.nm_6.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_6.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_6.Name = "nm_6";
            this.nm_6.Size = new System.Drawing.Size(44, 20);
            this.nm_6.TabIndex = 1;
            this.nm_6.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // nm_powerball
            // 
            this.nm_powerball.Location = new System.Drawing.Point(378, 39);
            this.nm_powerball.Maximum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nm_powerball.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nm_powerball.Name = "nm_powerball";
            this.nm_powerball.Size = new System.Drawing.Size(44, 20);
            this.nm_powerball.TabIndex = 1;
            this.nm_powerball.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lotto Numbers";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(375, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Power ball";
            // 
            // timer1
            // 
            this.timer1.Interval = 900;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // btn_Go
            // 
            this.btn_Go.Location = new System.Drawing.Point(193, 88);
            this.btn_Go.Name = "btn_Go";
            this.btn_Go.Size = new System.Drawing.Size(75, 23);
            this.btn_Go.TabIndex = 4;
            this.btn_Go.Text = "Go";
            this.btn_Go.UseVisualStyleBackColor = true;
            this.btn_Go.Click += new System.EventHandler(this.btn_Go_Click);
            // 
            // btn_Cheat
            // 
            this.btn_Cheat.Location = new System.Drawing.Point(437, 4);
            this.btn_Cheat.Name = "btn_Cheat";
            this.btn_Cheat.Size = new System.Drawing.Size(16, 23);
            this.btn_Cheat.TabIndex = 5;
            this.btn_Cheat.Text = "b";
            this.btn_Cheat.UseVisualStyleBackColor = true;
            this.btn_Cheat.Click += new System.EventHandler(this.btn_Cheat_Click);
            // 
            // timeToCheat
            // 
            this.timeToCheat.Interval = 15000;
            this.timeToCheat.Tick += new System.EventHandler(this.timeToCheat_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(453, 210);
            this.Controls.Add(this.btn_Cheat);
            this.Controls.Add(this.btn_Go);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nm_powerball);
            this.Controls.Add(this.nm_6);
            this.Controls.Add(this.nm_5);
            this.Controls.Add(this.nm_4);
            this.Controls.Add(this.nm_3);
            this.Controls.Add(this.nm_2);
            this.Controls.Add(this.nm_1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nm_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nm_powerball)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nm_1;
        private System.Windows.Forms.NumericUpDown nm_2;
        private System.Windows.Forms.NumericUpDown nm_3;
        private System.Windows.Forms.NumericUpDown nm_4;
        private System.Windows.Forms.NumericUpDown nm_5;
        private System.Windows.Forms.NumericUpDown nm_6;
        private System.Windows.Forms.NumericUpDown nm_powerball;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btn_Go;
        private System.Windows.Forms.Button btn_Cheat;
        private System.Windows.Forms.Timer timeToCheat;
    }
}

