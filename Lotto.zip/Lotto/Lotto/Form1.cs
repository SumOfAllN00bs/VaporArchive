﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lotto
{
    public unsafe  partial class Form1 : Form
    {
        int resultsDisplayed = 0;
        NumericUpDown[] numbers = new NumericUpDown[7];
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private void CheckIfWon()
        {
            timer1.Stop();
            //MessageBox.Show("powerball: " + result.Name);
            int matched = 0;
            bool powerballMatched = false;
            for (int i = 0; i < 7; i++)
            {
                //we have to compare the value of the numericupdown with the labels created so we have to search through the labels for the name we gave them
                Label tmpLabel = this.Controls.OfType<Label>().FirstOrDefault(r => r.Name == "lbl_" + (i + 1).ToString());//Wow Complicated
                int tmpInt = Convert.ToInt32(tmpLabel.Text);
                if (numbers[i].Value == tmpInt && i != 6)
                {
                    matched += 1;
                }
                else if (numbers[i].Value == tmpInt && i == 6)
                {
                    powerballMatched = true;
                }
            }
            MessageBox.Show("Matching numbers: " + matched);
            switch (matched)
            {
                case 0:
                    MessageBox.Show("Prize: Sorry better luck next time");
                    break;
                case 1:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 10 : 10).ToString());
                    break;
                case 2:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 50 : 50).ToString());
                    break;
                case 3:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 100 : 100).ToString());
                    break;
                case 4:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 1000 : 1000).ToString());
                    break;
                case 5:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 10000 : 10000).ToString());
                    break;
                case 6:
                    MessageBox.Show("Prize: $" + (powerballMatched ? 10 * 100000 : 100000).ToString());
                    break;

                default:
                    break;
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Label result = new Label();

            result.Text = rand.Next(1, 40).ToString();
            result.AutoSize = true;
            result.Location = new Point(numbers[resultsDisplayed].Location.X, numbers[resultsDisplayed].Location.Y + 100);
            result.Name = "lbl_" + (resultsDisplayed + 1).ToString();
            this.Controls.Add(result);
            //Update();
            if (resultsDisplayed == 5)
            {
                timer1.Interval = 1500;
            }
            if (resultsDisplayed == 6)
            {
                CheckIfWon();
            }
            else
            {
                resultsDisplayed++;
            }
        }

        private void btn_Go_Click(object sender, EventArgs e)
        {
            nm_1.Enabled = false;
            nm_2.Enabled = false;
            nm_3.Enabled = false;
            nm_4.Enabled = false;
            nm_5.Enabled = false;
            nm_6.Enabled = false;
            nm_powerball.Enabled = false;
            btn_Go.Enabled = false;
            MessageBox.Show("Here are the Results");
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            numbers[0] = nm_1;
            numbers[1] = nm_2;
            numbers[2] = nm_3;
            numbers[3] = nm_4;
            numbers[4] = nm_5;
            numbers[5] = nm_6;
            numbers[6] = nm_powerball;
            btn_Cheat.FlatStyle = FlatStyle.Flat;
            btn_Cheat.FlatAppearance.BorderColor = BackColor;
            btn_Cheat.FlatAppearance.MouseOverBackColor = BackColor;
            btn_Cheat.FlatAppearance.MouseDownBackColor = BackColor;
        }

        private void btn_Cheat_Click(object sender, EventArgs e)
        {
            nm_1.Enabled = true;
            nm_2.Enabled = true;
            nm_3.Enabled = true;
            nm_4.Enabled = true;
            nm_5.Enabled = true;
            nm_6.Enabled = true;
            nm_powerball.Enabled = true;
            timeToCheat.Start();
        }

        private void timeToCheat_Tick(object sender, EventArgs e)
        {
            nm_1.Enabled = false;
            nm_2.Enabled = false;
            nm_3.Enabled = false;
            nm_4.Enabled = false;
            nm_5.Enabled = false;
            nm_6.Enabled = false;
            nm_powerball.Enabled = false;
            timeToCheat.Stop();
            CheckIfWon();
        }
    }
}
