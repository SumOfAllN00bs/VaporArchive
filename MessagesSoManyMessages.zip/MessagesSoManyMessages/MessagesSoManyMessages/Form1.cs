﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MessagesSoManyMessages
{
    public partial class Form1 : Form
    {
        string[] Messages = new string[3] { "Are you listening", "How Are you", "hi" };
        int i;//index into Messages

        private bool SendMessage()
        {
            
            MessageBox.Show(Messages[i - 1]);
            i--;
            if (i == 0)
            {
                return true;
            }
            return false;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_SendMessage_Click(object sender, EventArgs e)
        {
            bool continue_Messages = true;
            i = Messages.Length;
            do
            {
                if (SendMessage()) continue_Messages = false;
            } while (continue_Messages);
            i = Messages.Length;
        }
    }
}
