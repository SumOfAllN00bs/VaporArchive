﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ih8BenAffleck
{
    public partial class Form1 : Form
    {
        string name;
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_go_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrWhiteSpace(txt_name.Text))
            {
                return;
            }
            else
            {
                name = txt_name.Text;
                string[] pieces = name.Split(' ');
                MessageBox.Show("Your first name is: \"" + pieces[0] + "\" your last name is: \"" + pieces.Last<string>() + "\"");
            }
        }
    }
}
